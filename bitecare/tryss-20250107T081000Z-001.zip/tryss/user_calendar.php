<?php
// Set timezone to the Philippines
date_default_timezone_set('Asia/Manila');

// Database connection
$conn = new mysqli('localhost', 'root', '', 'bitecare_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get month and year from request or default to current
$month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$first_day_of_month = date('Y-m-01', strtotime($month));
$last_day_of_month = date('Y-m-t', strtotime($month));

// Fetch slots for the requested month
$query = "SELECT * FROM appointment_slots WHERE date BETWEEN '$first_day_of_month' AND '$last_day_of_month' ORDER BY date ASC";
$result = $conn->query($query);

// Initialize an array to store available slots for each date
$slots = [];
while ($row = $result->fetch_assoc()) {
    $slots[$row['date']] = [
        'available_slots' => $row['available_slots'],
        'status' => $row['status']
    ];
}

// Get today's date (Philippines timezone)
$today = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Calendar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        h1 {
            text-align: center;
            font-size: 1.8rem;
            color: #333;
            margin-bottom: 20px;
        }
        .calendar {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            margin-bottom: 10px;
        }
        .header button {
            background: transparent;
            border: none;
            font-size: 1.5rem;
            color: #007bff;
            cursor: pointer;
        }
        .header button:hover {
            color: #0056b3;
        }
        .month-name {
            font-size: 1.5rem;
            color: #333;
            font-weight: bold;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            width: 14.28%;
            padding: 20px;
            text-align: center;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
        }
        td {
            background-color: #f8f9fa;
            color: #333;
            font-size: 1rem;
            position: relative;
        }
        td.today {
            background-color: #fff9c4; /* Light yellow for today */
            border: 1px solid #ffeb3b;
        }
        td.available {
            cursor: pointer;
            font-weight: bold;
            color: #007bff;
        }
        td.available:hover {
            background-color: #e9ecef;
        }
        td.unavailable {
           
        }
        td.empty {
            background-color: transparent;
            border: none;
        }
        .slots {
            display: block;
            margin-top: 5px;
            font-size: 0.9rem;
            font-weight: normal;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Appointment Availability</h1>
        <div class="calendar">
            <div class="header">
                <button onclick="changeMonth('prev')">&#8249;</button>
                <div class="month-name"><?= date('F Y', strtotime($month)) ?></div>
                <button onclick="changeMonth('next')">&#8250;</button>
            </div>
            <table>
                <tr>
                    <th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
                </tr>
                <?php
                // Get the first day of the month and number of days in the month
                $first_day_of_month = date('w', strtotime("$month-01"));
                $days_in_month = date('t', strtotime($month));
                $day = 1;

                // Print calendar rows
                for ($row = 0; $row < 6; $row++) {
                    echo "<tr>";
                    for ($col = 0; $col < 7; $col++) {
                        if ($row === 0 && $col < $first_day_of_month || $day > $days_in_month) {
                            echo "<td class='empty'></td>";
                        } else {
                            $date = "$month-" . str_pad($day, 2, '0', STR_PAD_LEFT);
                            $class = '';
                            $slots_text = '';

                            if ($date === $today) {
                                $class .= ' today';
                            }
                            if (isset($slots[$date])) {
                                $slots_text = $slots[$date]['available_slots'] . ' Slots';
                                if ($slots[$date]['status'] === 'available' && $slots[$date]['available_slots'] > 0) {
                                    $class .= ' available';
                                } else {
                                    $class .= ' unavailable';
                                }
                            } else {
                                $class .= ' unavailable';
                            }

                            echo "<td class='$class' data-date='$date'>$day";
                            if ($slots_text) {
                                echo "<br><span class='slots'>$slots_text</span>";
                            }
                            echo "</td>";
                            $day++;
                        }
                    }
                    echo "</tr>";
                    if ($day > $days_in_month) break;
                }
                ?>
            </table>
        </div>
    </div>

    <script>
        function changeMonth(direction) {
            const urlParams = new URLSearchParams(window.location.search);
            let currentMonth = urlParams.get('month') || '<?= date('Y-m') ?>';
            const date = new Date(currentMonth + '-01');

            if (direction === 'prev') {
                date.setMonth(date.getMonth() - 1);
            } else if (direction === 'next') {
                date.setMonth(date.getMonth() + 1);
            }

            const newMonth = date.toISOString().slice(0, 7);
            window.location.href = `?month=${newMonth}`;
        }

        document.querySelectorAll('.available').forEach(cell => {
            cell.addEventListener('click', () => {
                const date = cell.getAttribute('data-date');
                if (confirm(`Reserve a slot for ${date}?`)) {
                    fetch('reserve.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ date })
                    }).then(response => response.json())
                      .then(data => {
                          if (data.success) {
                              const slotsElement = cell.querySelector('.slots');
                              slotsElement.textContent = `${data.remaining_slots} Slots`;
                              if (data.remaining_slots === 0) {
                                  cell.classList.remove('available');
                                  cell.classList.add('unavailable');
                              }
                              alert('Reservation successful!');
                          } else {
                              alert(data.message || 'Reservation failed!');
                          }
                      })
                      .catch(error => console.error('Error:', error));
                }
            });
        });
    </script>
</body>
</html>
